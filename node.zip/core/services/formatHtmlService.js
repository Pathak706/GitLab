function formatHTML(projects) {
    //console.log(JSON.stringify(projects, null, 2))
    return new Promise(function(resolve, reject) {
        resolve("<b> Data is Ready </b>");
    });
}
module.exports = formatHTML;
